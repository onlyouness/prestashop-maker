<?php

declare(strict_types=1);

namespace LNKBOOT\LnkCustomblock\Form;

use PrestaShop\PrestaShop\Core\Configuration\DataConfigurationInterface;
use PrestaShop\PrestaShop\Core\ConfigurationInterface;

class CustomblockDataConfiguration implements DataConfigurationInterface
{
    private ConfigurationInterface $configuration;

    public function __construct(ConfigurationInterface $configuration)
    {
        $this->configuration = $configuration;
    }

    public const LNK_CUSTOMBLOCK_DESCRIPTION = 'LNK_CUSTOMBLOCK_DESCRIPTION';


    public function getConfiguration(): array
    {
        $return = [];
        $return['description'] = $this->configuration->get(static::LNK_CUSTOMBLOCK_DESCRIPTION);

        return $return;
    }

    public function updateConfiguration(array $configuration): array
    {
        $errors = [];

        if ($this->validateConfiguration($configuration)) {
        $this->configuration->set(static::LNK_CUSTOMBLOCK_DESCRIPTION, $configuration['description']);

        }

        return $errors;
    }

    public function validateConfiguration(array $configuration): bool
    {
        // return isset($configuration['description']);
        return true;
    }
}