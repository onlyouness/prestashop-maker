<?php

declare(strict_types=1);

namespace LNKBOOT\LnkCustomblock\Form;

use PrestaShop\PrestaShop\Core\Form\FormDataProviderInterface;

class CustomblockFormDataProvider implements FormDataProviderInterface
{
    private CustomblockDataConfiguration $dataConfiguration;

    public function __construct(CustomblockDataConfiguration $dataConfiguration)
    {
        $this->dataConfiguration = $dataConfiguration;
    }

    public function getData(): array
    {
        return $this->dataConfiguration->getConfiguration();
    }

    public function setData(array $data): array
    {
        return $this->dataConfiguration->updateConfiguration($data);
    }
}