<?php

declare(strict_types=1);

namespace LNKBOOT\LnkCustomblock\Controller;

use PrestaShop\PrestaShop\Core\Form\FormHandlerInterface;
use PrestaShopBundle\Controller\Admin\PrestaShopAdminController;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class CustomblockConfigurationController extends PrestaShopAdminController
{
    public function index(
        Request $request,
        #[Autowire(service: 'prestashop.module.lnk_customblock.form.customblock_form_data_handler')]
        FormHandlerInterface $formDataHandler,
    ): Response {
        $form = $formDataHandler->getForm();
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $errors = $formDataHandler->save($form->getData());

            if (empty($errors)) {
                $this->addFlash('success', $this->trans('Successful update.', [], 'Admin.Notifications.Success'));

                return $this->redirectToRoute('lnk_customblock_configuration_customblock');
            }

            $this->addFlashErrors($errors);
        }

        return $this->render('@Modules/lnk_customblock/views/templates/admin/form.html.twig', [
            'customblockForm' => $form->createView(),
        ]);
    }
}