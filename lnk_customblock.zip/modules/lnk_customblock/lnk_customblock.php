<?php

class Lnk_customblock extends Module
{
    public function __construct()
    {
        $this->name          = 'lnk_customblock';
        $this->tab           = 'administration';
        $this->version       = '1.0.0';
        $this->author        = 'LNKBOOT';
        $this->need_instance = 0;
        $this->bootstrap     = true;

        parent::__construct();

        $this->displayName = $this->trans('lnk_customblock', [], 'Modules.Lnk_customblock.Admin');
        $this->description = $this->trans('description', [], 'Modules.Lnk_customblock.Admin');

        $this->ps_versions_compliancy = [
            'min' => '9.0.0',
            'max' => _PS_VERSION_,
        ];
    }
    public function install(): bool
    {
        return parent::install() &&
            $this->installDb()
            && $this->registerHook([
                'displayProductAdditionalInfo',
            ]);
    }

    public function uninstall(): bool
    {
        return
            $this->unInstallDb() && parent::uninstall();
    }

    public function installDb(): bool
    {
        return true;
    }
    public function unInstallDb(): bool
    {
        return true;
    }


    public function hookDisplayProductAdditionalInfo($params)
    {
        // Logic for displayProductAdditionalInfo
    }
    public function getContent()
    {
        $homePage = Link::getUrlSmarty(['entity' => 'sf', 'route' => 'lnk_customblock_configuration_customblock']);
        Tools::redirectAdmin($homePage);
    }
}
